<?php
// Wrapper đồng bộ: load thư viện hàm chính của Bài 4
// BTVN chứa file `bai4_functions.php`; để mọi file khác require `BTTL/functions.php` hoặc `BTVN/functions.php` vẫn tương thích,
// ta require file chính từ đây (đường dẫn tới BTVN).
require_once __DIR__ . '/../BTVN/bai4_functions.php';

