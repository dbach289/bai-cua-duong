<?php
// Bài 3: Vòng lặp (for / while / continue / break)
// Thực hiện:
// A) In bảng cửu chương 1..9 bằng HTML (dùng for lồng nhau)
// B) Tính tổng chữ số của n (dùng while)
// C) In các số lẻ từ 1..N (dùng continue để bỏ chẵn; dùng break để dừng khi vượt 15)

$rawN = isset($_REQUEST['n']) ? trim($_REQUEST['n']) : '';
$n = null;
$errors = [];
$sumDigits = null;
$oddList = [];

if ($rawN === '') {
    // Nếu không có tham số n (người dùng chưa nhập) -> thêm thông báo lỗi để hiển thị
    $errors[] = 'Vui lòng nhập tham số n (qua form hoặc ?n=...).';
} else {
    // Kiểm tra n có phải số nguyên dương không
    if (!is_numeric($rawN) || (float)$rawN != intval($rawN)) {
        $errors[] = 'Tham số n phải là số nguyên.';
    } else {
        $n = intval($rawN);
        if ($n < 0) {
            $errors[] = 'Tham số n phải là số nguyên không âm.';
        } else {
            // B) Tính tổng chữ số của n bằng while
            // Ý tưởng: lấy từng chữ số bằng phép lấy phần dư 10, rồi chia nguyên cho 10 để lặp
            $temp = abs($n); // dùng giá trị tuyệt đối để xử lý n >= 0
            $sumDigits = 0;
            if ($temp === 0) {
                // Trường hợp n = 0 -> tổng chữ số là 0
                $sumDigits = 0;
            } else {
                // Vòng while sẽ tách từng chữ số cho tới khi temp = 0
                while ($temp > 0) {
                    $sumDigits += $temp % 10; // lấy chữ số cuối cùng và cộng vào tổng
                    $temp = intdiv($temp, 10); // loại bỏ chữ số cuối cùng (chia nguyên cho 10)
                }
            }

            // C) In các số lẻ từ 1..N, dùng continue để bỏ số chẵn và break khi vượt 15
            // Duyệt i từ 1 tới n:
            // - nếu i > 15 thì dừng vòng (yêu cầu: dừng khi vượt 15)
            // - nếu i chẵn (i % 2 == 0) thì continue (bỏ qua, không in)
            // - nếu không, thêm i vào danh sách oddList để in sau
            for ($i = 1; $i <= $n; $i++) {
                if ($i > 15) {
                    break; // dừng vòng lặp khi giá trị vượt 15 (không cần xử lý tiếp)
                }
                if ($i % 2 == 0) {
                    continue; // số chẵn -> bỏ qua (không thêm vào danh sách)
                }
                // Nếu tới đây thì i là số lẻ và <= 15 -> thêm vào danh sách kết quả
                $oddList[] = $i;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="utf-8"/>
    <title>Bài 3 - Vòng lặp</title>
    <style>
        /* Một chút style để bảng cửu chương gọn hơn */
        .tables { display: flex; flex-wrap: wrap; gap: 10px; }
        .table-box { border: 1px solid #ccc; padding: 8px; width: 180px; }
        .table-box h4 { margin: 0 0 6px 0; }
        .table-box ul { margin: 0; padding-left: 18px; }
    </style>
</head>
<body>
    <h1>Bài 3 — Vòng lặp</h1>

    <form method="get" action="">
        <label for="n">Nhập n (số nguyên không âm): </label>
        <input type="text" id="n" name="n" value="<?php echo htmlspecialchars($rawN, ENT_QUOTES, 'UTF-8'); ?>" />
        <button type="submit">Chạy</button>
    </form>

    <?php if (!empty($errors)): ?>
        <div style="color: red;">
            <?php foreach ($errors as $err) { echo htmlspecialchars($err, ENT_QUOTES, 'UTF-8') . "<br>"; } ?>
        </div>
    <?php endif; ?>

    <?php if ($n !== null): ?>
        <!-- A) Bảng cửu chương 1..9 -->
        <h2>Bảng cửu chương 1..9</h2>
        <div class="tables">
            <?php for ($i = 1; $i <= 9; $i++): ?>
                <div class="table-box">
                    <h4><?php echo "Bảng $i"; ?></h4>
                    <ul>
                        <?php for ($j = 1; $j <= 10; $j++): ?>
                            <li><?php echo "$i x $j = " . ($i * $j); ?></li>
                        <?php endfor; ?>
                    </ul>
                </div>
            <?php endfor; ?>
        </div>

        <!-- B) Tổng chữ số -->
        <h2>Tổng chữ số của <?php echo $n; ?></h2>
        <p><?php echo "Tổng các chữ số của $n là " . $sumDigits . "."; ?></p>

        <!-- C) In số lẻ 1..N (continue để bỏ chẵn; break khi vượt 15) -->
        <h2>Các số lẻ từ 1 đến <?php echo $n; ?> (dừng khi >15)</h2>
        <?php if (empty($oddList)): ?>
            <p>Không có số lẻ nào (hoặc các số lẻ đều lớn hơn 15).</p>
        <?php else: ?>
            <p><?php echo implode(', ', $oddList); ?></p>
        <?php endif; ?>
    <?php endif; ?>

    <p>Test nhanh bằng URL:</p>
    <ul>
        <li><a href="?n=25">?n=25</a></li>
        <li><a href="?n=12345">?n=12345 (tổng chữ số)</a></li>
        <li><a href="?n=5">?n=5</a></li>
    </ul>

    <p><a href="../BTTL/">Về trang chính Lab</a></p>
</body>
</html>


