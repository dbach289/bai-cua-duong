<?php
// Wrapper để đồng bộ tên file functions.php với thư viện hàm của Bài 4
// File này chỉ require file chính chứa hàm: bai4_functions.php

require_once __DIR__ . '/bai4_functions.php';


