<h2>Danh sách sinh viên</h2>

<form id="studentForm">
    <input name="code" placeholder="Mã sinh viên">
    <input name="full_name" placeholder="Họ tên">
    <input name="email" placeholder="Email">
    <input name="dob" type="date">
    <button type="submit">Thêm</button>
</form>

<table id="tbl">
    <thead>
        <tr>
            <th>STT</th>
            <th>Mã SV</th>
            <th>Họ tên</th>
            <th>Email</th>
            <th>Ngày sinh</th>
            <th>Thao tác</th>
        </tr>
    </thead>
    <tbody></tbody>
</table>
