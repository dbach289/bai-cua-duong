<?php
return [
    'host' => 'localhost',
    'dbname' => 'it3220_php',
    'user' => 'root',
    'pass' => '',
    'charset' => 'utf8mb4'
];
